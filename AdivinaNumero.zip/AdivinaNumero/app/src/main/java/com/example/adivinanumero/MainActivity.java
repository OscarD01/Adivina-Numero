package com.example.adivinanumero;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button btn = findViewById(R.id.btnEnviar);
        final TextView etTexto = findViewById(R.id.etTexto);
        etTexto.setInputType(InputType.TYPE_CLASS_NUMBER);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int numGuess = (int) (Math.random() * 100 + 1);
                int numUser = Integer.parseInt(etTexto.getText().toString());
                if (numUser > numGuess) {
                    Toast.makeText(MainActivity.this, "El numero que has introducido es mas grande", Toast.LENGTH_SHORT).show();
                    etTexto.setText("");
                } else if (numUser < numGuess) {
                    Toast.makeText(MainActivity.this, "El numero que has introducido es mas pequeño", Toast.LENGTH_SHORT).show();
                    etTexto.setText("");
                } else if (numUser == numGuess) {
                    Toast.makeText(MainActivity.this, "Correcto", Toast.LENGTH_SHORT).show();
                    etTexto.setText("");
                }
            }

        });
    }
}